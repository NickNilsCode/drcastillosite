<!DOCTYPE php>
<html lang="en">
<head>
	<meta charset="utf-8">
	<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<meta name="author" content="DevSolutions">
	<meta name="description" content="<?php echo $description;?>">

	<title><?php echo $title;?></title>

	<!-- Fonts Google Roboto & Glego, Glyphicons, Font Awesome, AND Icons  -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic%7CMontserrat:400,700%7COpen+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
	
	<link rel="stylesheet" href="assets/icons/devsolution-icons/style.css">
	<link rel="stylesheet" href="assets/icons/glyphicons/style.min.css">
	<link rel="stylesheet" href="assets/icons/font-awesome/css/font-awesome.min.css">

	<!-- Bootstrap -->
	<link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">

	<!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
	<link rel="stylesheet" type="text/css" href="assets/plugins/revolution/rs-plugin/css/settings.css" media="screen" />

	<!-- Style -->
	<link rel="stylesheet" href="assets/css/style.css">

	<!-- Responsive -->
	<link rel="stylesheet" href="assets/css/responsive.css">

	<!-- CSS Plugin -->
	<link rel="stylesheet" href="assets/plugins/jquery-ui/jquery-ui.min.css">
	<link rel="stylesheet" href="assets/plugins/jquery-ui/jquery-ui.theme.css">
	<link rel="stylesheet" href="assets/plugins/mfp/jquery.mfp.css">
	<link rel="stylesheet" href="assets/plugins/owlcarousel/owl.carousel.min.css">

	<!-- Skin -->
	<link rel="stylesheet" id="skin-color" href="assets/css/blue.css">

	<script type="text/javascript" src="assets/plugins/jquery/dist/jquery.min.js"></script>

</head>
