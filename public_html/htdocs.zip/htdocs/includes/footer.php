<!-- Footer -->
		<footer class="footer">
			<div class="row">
				<div class="col-md-4 widget">
					<h2>Come to our office</h2>
					<p>
						Luis Castillo Professional Dental Corp.<br>
						5359 N Fresno St # 110 <br>
						Fresno, CA  93710 					</p>			
				</div>
				<div class="col-md-4 widget">
					<h2>Office Hours</h2>
					<p>
						Monday to Friday: 8:00am - 5:30pm<br>
						Saturday: By Appointment<br>
						Sunday: Closed
					</p>
				</div>
				<div class="col-md-4 widget">
					<h2>Contact Us</h2>
					<p>
						<i class="fa fa-envelope"></i>dentalsmiles222@gmail.com<br>
						<i class="fa fa-phone"></i>(559) 221- 0302<br>	
					</p>
				</div>
			</div>
			<div class="bottom-footer">
				<div class="container">
					<div class="row">
						<div class="col-md-8">
							<p><span>Luis Castillo</span> - Professional Dental Corporation. All rights reserved 2016.</p>
						</div>
						<div class="col-md-4">
							<ul class="bottom-social">
								<li><a class="facebook-bar" href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a class="google-bar" href="#"><i class="fa fa-google-plus"></i></a></li>
								<li><a class="pinterest-bar" href="#"><i class="fa fa-pinterest"></i></a></li>
								<!-- <li><a class="youtube-bar" href="#"><i class="fa fa-youtube-play"></i></a></li>
								<li><a class="rss-bar" href="#"><i class="fa fa-rss"></i></a></li> -->
							</ul>
						</div>
					</div>
				</div>

				<a href="#" class="top-scroll">
					<i class="fa fa-angle-up"></i>
				</a>
			</div>
		</footer>
		<!-- /Footer -->